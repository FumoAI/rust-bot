use kovi::build_bot;

fn main() {
    build_bot!(hi).run();
}
